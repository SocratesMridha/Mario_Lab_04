﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CanvasManager : MonoBehaviour {

	// References to Buttons in Scene
	public Button startBtn;
	public Button quitBtn;

	// Use this for initialization
	void Start () {

		// Check if Button was set
		if (startBtn)
			// Adds the 'StartGame' function from GameManager to Start Button
			startBtn.onClick.AddListener(GameManager.instance.StartGame);

		// Check if Button was set
		if (quitBtn)
			// Adds the 'QuitGame' function from GameManager to Quit Button
			quitBtn.onClick.AddListener(GameManager.instance.QuitGame);

	}
}
