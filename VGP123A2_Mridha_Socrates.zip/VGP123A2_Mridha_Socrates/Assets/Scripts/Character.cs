﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character : MonoBehaviour {

	// Method 1: Reference Rigidbody2D through script
	// - Not shown in Inspector
	Rigidbody2D rb;

	// Method 2: Reference Rigidbody2D through script
	// - Shown in Inspector
	public Rigidbody2D rb2;

	// Handle movement speed of Character
	// - Can be adjusted through Inspector while in Play mode
	public float speed;

	// Handles jump speed of Character
	public float jumpForce;             // How high the character will Jump
	public bool isGrounded;             // Is the player touching the ground?
	public LayerMask isGroundLayer;     // What is the Ground? Player can only jump on things that are on the "Ground" layer  
	public Transform groundCheck;       // Used to figure out if the player is touching the ground
	public float groundCheckRadius;     // Size of circle around empty GameObject


	// Handles animations
	public Animator anim;

	// Handle projectile Instantiation (aka Creation)
	public Transform projectileSpawnPoint;
	public Projectile projectilePrefab;
	public float projectileForce;

	// Handles Character flipping
	public bool isFacingRight;

	// Handles amount of lives
	int _lives;

	// Use this for initialization
	void Start () {

		// Method 1: Reference Rigidbody through script
		rb = GetComponent<Rigidbody2D>();

		// Checks if Component exists
		if (!rb)
		{
			// Prints a message to Console (Shortcut: Control+Shift+C)
			Debug.LogWarning("No Rigidbody2D found.");
		}

		// Checks if Component exists
		if (!rb2)
		{
			// Prints a message to Console (Shortcut: Control+Shift+C)
			rb2 = GetComponent<Rigidbody2D>();
		}

		// Check if speed was set to something not 0
		if (speed <= 0)
		{
			// Assign a default value if one is not set in the Inspector
			speed = 2.0f;

			// Prints a message to Console (Shortcut: Control+Shift+C)
			Debug.LogWarning("Default speed to " + speed);
		}

		// Check if speed was set to something not 0
		if (jumpForce == 0)
		{
			// Assign a default value if one is not set in the Inspector
			jumpForce = 4.0f;

			// Prints a message to Console (Shortcut: Control+Shift+C)
			Debug.Log("Jump Force was not set. Defaulting to " + jumpForce);
		}

		// Checks if GroundCheck GameObject is connected
		if (!groundCheck)
		{
			// Prints a message to Console (Shortcut: Control+Shift+C)
			Debug.LogError("No Ground Check found on GameObject");
		}

		// Check if speed was set to something not 0
		if (groundCheckRadius == 0)
		{
			// Assign a default value if one is not set in the Inspector
			groundCheckRadius = 0.2f;

			// Prints a message to Console (Shortcut: Control+Shift+C)
			Debug.Log("Ground Check Radius was not set. Defaulting to " + groundCheckRadius);
		}

		// Reference Component through script
		anim = GetComponent<Animator>();

		// Checks if Component exists
		if (!anim)
		{
			// Prints a message to Console (Shortcut: Control+Shift+C)
			Debug.LogError("No Animator found on GameObject");
		}

		// Checks if projectileSpawnPoint GameObject is connected
		if (!projectileSpawnPoint)
		{
			// Prints a message to Console (Shortcut: Control+Shift+C)
			Debug.LogError("No projectileSpawnPoint found on GameObject");
		}

		// Checks if projectileSpawnPoint GameObject is connected
		if (!projectilePrefab)
		{
			// Prints a message to Console (Shortcut: Control+Shift+C)
			Debug.LogError("No projectilePrefab found on GameObject");
		}

		// Check if speed was set to something not 0
		if (projectileForce == 0)
		{
			// Assign a default value if one is not set in the Inspector
			projectileForce = 2.0f;

			// Prints a message to Console (Shortcut: Control+Shift+C)
			Debug.Log("projectileForce was not set. Defaulting to " + projectileForce);
		}

		lives = 0;
		score = 0;
	}

	// Update is called once per frame
	void Update()
	{

		// Check if groundCheck GameObject is touching something tagged as Ground or Platform
		// - Can change groundCheckRadius to a smaller value if you need more precision or if the sizing of the Character is small
		isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius,
			isGroundLayer);

		// Checks if Left (or a) or Right (or d) is pressed
		// - "Horizontal" must exist in Input Manager (Edit-->Project Settings-->Input)
		// - Returns -1(left), 1(right), 0(nothing)
		// - Use GetAxis for value -1-->0-->1 and all decimal places. (Gradual change in values)
		float moveValue = Input.GetAxisRaw("Horizontal");

		// Check if "Jump" button was pressed
		// - "Jump" must exist in Input Manager (Edit-->Project Settings-->Input)
		// - Configuration can be changed later
		if (Input.GetButtonDown("Jump"))
		{
			// Prints a message to Console (Shortcut: Control+Shift+C)
			Debug.Log("Jump");

			// Vector2.up --> new Vector2(0,1);
			// Vector2.down --> new Vector2(0,-1);
			// Vector2.right --> new Vector2(1,0);
			// Vector2.left --> new Vector2(-1,0);

			// Applies a force in the UP direction
			rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
		}

		// Check if Left Control was pressed\
		// - Tied to key and cannot be changed
		if (Input.GetKeyDown(KeyCode.LeftControl))
		{
			// Prints a message to Console (Shortcut: Control+Shift+C)
			Debug.Log("Pew pew");

			// Call function to make pew pew
			fire();
		}

		// Move Character using Rigidbody2D
		// - Uses moveValue from GetAxis to move left or right
		rb.velocity = new Vector2(moveValue * speed, rb.velocity.y);

		// Tells Animator to transition to another Clip
		// - Parameter must be created in Animator window
		anim.SetFloat("MoveValue", Mathf.Abs(moveValue));

		// Check if Character should flip and look left and right
		if((isFacingRight && moveValue < 0) || (!isFacingRight && moveValue > 0))
			// Call function to flip Character
			flip();

		if (Input.GetButtonDown ("Jump")) 
		{
			anim.SetInteger ("State", 2);
		}
		if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.LeftArrow)) 
		{
			anim.SetInteger ("State", 1);
		}
		if (Input.GetKeyDown(KeyCode.DownArrow)) 
		{
			anim.SetInteger ("State", 3);
		}
		if (Input.GetKeyUp(KeyCode.RightArrow) || Input.GetKeyUp(KeyCode.LeftArrow) ||Input.GetKeyUp(KeyCode.DownArrow) || Input.GetButtonUp("Jump"))
		{
			anim.SetInteger("State",0);
		}

	}

	// Function used to create and fire a Projectile
	void fire()
	{
		// Creates Projectile and add its to the Scene
		// - projectPrefab is the thing to create
		// - projectileSpawnPoint is where and what rotation to use when created
		Projectile temp = 
			Instantiate(projectilePrefab, projectileSpawnPoint.position, projectileSpawnPoint.rotation);

		temp.GetComponent<Rigidbody2D>().velocity =
            new Vector2(projectileForce, 0);

        temp.GetComponent<Rigidbody2D>().velocity =
            Vector2.right * projectileForce;
        

		// Apply movement speed to Projectile that is spawned
		// - Lets the projectile handle its own movement
		temp.speed = projectileForce;
	}

	// Function used to flip direction GameObject (Character) is facing
	void flip()
	{
		// Method 1: Toggle isFacingRight variable
		isFacingRight = !isFacingRight;

		// Method 2: Toggle isFacingRight variable
		/*
        if (isFacingRight)
            isFacingRight = false;
        else
            isFacingRight = true;
        */

		// Make a copy of old scale value
		Vector3 scaleFactor = transform.localScale;

		// Flip scale of 'x' variable
		scaleFactor.x *= -1;    // scaleFactor.x = -scaleFactor.x;

		// Update scale to new flipped value
		transform.localScale = scaleFactor;
	}

	private void OnTriggerEnter2D(Collider2D c)
	{
		// Check if 'Character' collided with a 'Collectible'
		if(c.gameObject.tag == "Collectible")
		{
			// Grab the 'Collectible' Script to find the pointValue
			Collectible col = c.gameObject.GetComponent<Collectible>();

			// Check if 'Collectible' script exists
			if(col.gameObject.name == "Bonus Coin")
			{
				// Change 'score' variable in GameManager to Points from 'Collectible' script
				GameManager.instance.score = score + col.pointValue;
			}

			// Destroy 'Collectible'
			Destroy(c.gameObject);
		}
		if(c.gameObject.tag == "DeathBox")
		{
			Destroy(gameObject);
		}
	}
	private void OnCollisionEnter2D(Collision2D c)
	{

		if (c.gameObject.tag == "Brick") {
			if (c.gameObject.transform.position.y - 0.1 > gameObject.transform.position.y) {
				Destroy (c.gameObject);
			} 
		}
		if (c.gameObject.tag == "Brick_Coin") 
		{
			anim = c.gameObject.GetComponent<Animator>();
			anim.SetBool ("Hit", true);

		}
	}

	// Give access to private variables (instance variables)
	// - Not needed if using public variables
	public int lives
	{
		get { return _lives; }
		set { _lives = value;
			Debug.Log("Lives changed to " + _lives);
		}
	}

	// Give acces to private data (instance variables)
	// - Creates Variable and makes it accessible through get and set methods
	public int score
	{ get; set; }
}
