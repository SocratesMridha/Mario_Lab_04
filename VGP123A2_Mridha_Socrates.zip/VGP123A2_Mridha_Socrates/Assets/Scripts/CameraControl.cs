﻿using UnityEngine;
using System.Collections;

public class CameraControl : MonoBehaviour {

	[SerializeField]
	private float xMax=22;
	[SerializeField]
	private float yMax=0;
	[SerializeField]
	private float xMin=0;
	[SerializeField]
	private float yMin=0;

	private Transform target;
	private Transform cam;

	// Use this for initialization
	void Start () {
		target = GameObject.Find ("Mario").transform;
	}

	// Update is called once per frame
	void LateUpdate () {
		transform.position = new Vector3 (Mathf.Clamp (target.position.x, xMin, xMax), Mathf.Clamp (target.position.y, yMin, yMax), transform.position.z);
	}
}