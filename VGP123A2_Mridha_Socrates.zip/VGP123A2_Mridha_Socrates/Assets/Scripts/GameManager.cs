﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;  // Needed for SceneManager stuff
using UnityEngine.UI;

public class GameManager : MonoBehaviour {

	// Creates a class variable to keep track of 'GameManager' instance
	static GameManager _instance = null;

	// Used to instantiate 'Character'
	public GameObject playerPrefab;

	// Used to keep track of 'score' in game
	int _score;
	public Text scoreText;


	// Use this for initialization
	void Start()
	{
		// Check if 'GameManager' instance exists
		if (instance)
			// 'GameManager' already exists, delete copy
			DestroyImmediate(gameObject);
		else
		{
			// 'GameManager' does not exist so assign a reference to it
			instance = this;

			// Do not destroy 'GameManager' on Scene change
			DontDestroyOnLoad(this);
		}

		// Assign a starting score
		score = 0;
	}

	// Update is called once per frame
	void Update () {

		if(Input.GetKeyDown(KeyCode.Escape))
		{
			if (SceneManager.GetActiveScene ().name == "Level") {
				SceneManager.LoadScene ("TitleScreen");
			}
			else if (SceneManager.GetActiveScene ().name == "TitleScreen") {
				StartGame ();
			}
		}

	}

	// Gets called to Start game
	public void StartGame()
	{
		// Loads Level1 Scene
		SceneManager.LoadScene("Level");
	}


	// Gets called to Quit game
	public void QuitGame()
	{
		// Quits game (only works on EXE, not in Editor)
		Debug.Log("Quit Game.");

		Application.Quit();
	}


	// Called when 'Character' is spawned
	public void spawnPlayer(int spawnLocation)
	// public void spawnPlayer(Vector3 spawnLocation)
	// public void spawnPlayer(Transform spawnLocation)
	// public void spawnPlayer(GameObject spawnLocation)
	{
		// Requires spawnPoint to be named (SceneName)_(number)
		// - Level1_0
		string spawnPointName = SceneManager.GetActiveScene().name
			+ "_" + spawnLocation;

		// Find location to spawn 'Character' at
		Transform spawnPointTransform =
			GameObject.Find(spawnPointName).GetComponent<Transform>();

		// Instantiate (Create) 'Character' GameObject
		Instantiate(playerPrefab, spawnPointTransform.position,
			spawnPointTransform.rotation);
	}

	// Give access to private variables (instance variables)
	// - Not needed if using public variables
	// - Variable must be declared above
	// - Variable and method must be static
	public static GameManager instance
	{
		get { return _instance; }   // can also use just 'get;'
		set { _instance = value; }  // can also use just 'set;'
	}

	// Give access to private variables (instance variables)
	// - Not needed if using public variables
	public int score
	{
		get { return _score; }   // can also use just 'get;'
		set { _score = value;
			// Check if 'scoreText' was set before trying to update HUD
			if (scoreText)
				// Update HUD on every score change
				scoreText.text = "" + score;
		}  // can also use just 'set;'
	}
}
