﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collectible : MonoBehaviour {

    // Used to tell 'Character' how many points a 'Collectible' is worth
    public int pointValue;

	// Use this for initialization
	void Start () {

        // Check if 'pointValue' was set to something not 0
        if (pointValue <= 0)
            // Assign a default value to 'pointValue'
            pointValue = 200;
	}
}
